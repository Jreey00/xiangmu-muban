<template>
	<div class="card content-box">
		<iframe src="https://cn.bing.com/" frameborder="0" class="full-iframe"></iframe>
	</div>
</template>

<script setup lang="ts" name="embedded"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
