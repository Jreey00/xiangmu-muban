declare module "nprogress";
declare module "js-md5";
declare module "echarts-liquidfill";
declare module "qs";
